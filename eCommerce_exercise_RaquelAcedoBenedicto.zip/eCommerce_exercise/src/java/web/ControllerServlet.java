package web;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

import model.CategoryModel;
import model.ComandaModel;
import model.ProductModel;
import model.UserModel;
import web.action.*;

public class ControllerServlet extends HttpServlet {

    private HashMap actionMap;

    @Override
    public void init() throws ServletException {

        actionMap = new HashMap();
        ServletContext context = getServletContext();

        actionMap.put("/init.do", new initAction((CategoryModel) context.getAttribute("categoryModel"), (ComandaModel) context.getAttribute("comandaModel"), (ProductModel) context.getAttribute("productModel"), (UserModel) context.getAttribute("userModel")));
        actionMap.put("/category.do", new categoryAction((CategoryModel) context.getAttribute("categoryModel"),(ProductModel) context.getAttribute("productModel"), (UserModel) context.getAttribute("userModel")));
        actionMap.put("/neworder.do", new neworderAction((CategoryModel) context.getAttribute("categoryModel"),(ProductModel) context.getAttribute("productModel"), (UserModel) context.getAttribute("userModel")));
        actionMap.put("/viewcart.do", new viewcartAction((UserModel) context.getAttribute("userModel")));
        actionMap.put("/updatecart.do", new updatecartAction((ProductModel) context.getAttribute("productModel"), (UserModel) context.getAttribute("userModel")));
        actionMap.put("/clearcart.do", new clearcartAction((UserModel) context.getAttribute("userModel")));
        actionMap.put("/checkout.do", new checkoutAction((UserModel) context.getAttribute("userModel"), (ComandaModel) context.getAttribute("comandaModel")));
        actionMap.put("/login.do", new loginAction((CategoryModel) context.getAttribute("categoryModel")));
        actionMap.put("/checklogin.do", new checkloginAction((CategoryModel) context.getAttribute("categoryModel"), (UserModel) context.getAttribute("userModel"), (ComandaModel) context.getAttribute("comandaModel"), (ProductModel) context.getAttribute("productModel")));
        actionMap.put("/signin.do", new signinAction((CategoryModel) context.getAttribute("categoryModel"), (UserModel) context.getAttribute("userModel"), (ComandaModel) context.getAttribute("comandaModel"), (ProductModel) context.getAttribute("productModel")));
        actionMap.put("/logout.do", new logoutAction((CategoryModel) context.getAttribute("categoryModel"), (ComandaModel) context.getAttribute("comandaModel"),(UserModel) context.getAttribute("userModel"), (ProductModel) context.getAttribute("productModel")));
        actionMap.put("/historic.do", new historicAction((CategoryModel) context.getAttribute("categoryModel"),(ProductModel) context.getAttribute("productModel"), (UserModel) context.getAttribute("userModel"), (ComandaModel) context.getAttribute("comandaModel")));

    }

    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws IOException, ServletException {

        String op = req.getServletPath();
        Action action = (Action) actionMap.get(op);
        
        try {
            action.perform(req, resp);
        } catch (Exception e) {
            e.printStackTrace();
            RequestDispatcher dispatcher = req.getRequestDispatcher("/error.jsp");
            if (dispatcher != null) {
                dispatcher.forward(req, resp);
            }
        }
    }

    @Override
    public void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws IOException, ServletException {

        doPost(req, resp);
    }
}