/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package web.action;

import cart.ShoppingCart;
import entity.Comanda;
import entity.User;
import static java.lang.Integer.parseInt;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.CategoryModel;
import model.ComandaModel;
import model.ProductModel;
import model.UserModel;
import web.ViewManager;

/**
 *
 * @author raque
 */
public class logoutAction implements Action {
    
    CategoryModel categoryModel;
    ComandaModel comandaModel;
    UserModel userModel;
    ProductModel productModel;

    public logoutAction(CategoryModel categoryModel, ComandaModel comandaModel, UserModel userModel, ProductModel productModel){
        this.categoryModel = categoryModel;
        this.comandaModel = comandaModel;
        this.userModel = userModel;
        this.productModel = productModel;
    }
    
    public void perform(HttpServletRequest req, HttpServletResponse resp) {
        
        req.setAttribute("categories", categoryModel.retrieveAll());
        
        int idUser = new Integer(req.getParameter("idUser"));
        
        ShoppingCart shoppingCart = (ShoppingCart)req.getSession().getAttribute("shoppingCart");
        comandaModel.insertOrder(shoppingCart, idUser);
        shoppingCart.clear();
        req.setAttribute("nItems", shoppingCart.getNumberOfItems());
        
        List<Comanda> lastOrders = comandaModel.retrieveAll(idUser);
        req.setAttribute("lastOrders", lastOrders);
        req.setAttribute("user", null);
        req.setAttribute("productModel", productModel);
        
        ViewManager.nextView(req, resp, "/view/init.jsp");
    }
    
}
