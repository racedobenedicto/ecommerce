/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package web.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.CategoryModel;
import web.ViewManager;

/**
 *
 * @author raquel
 */
public class loginAction implements Action {
    
    CategoryModel categoryModel;

    public loginAction(CategoryModel categoryModel){
        this.categoryModel = categoryModel;
    }
    
    public void perform(HttpServletRequest req, HttpServletResponse resp) {
        
        req.setAttribute("categories", categoryModel.retrieveAll());
        
        ViewManager.nextView(req, resp, "/view/login.jsp");
    }
}
