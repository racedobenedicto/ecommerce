/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package web.action;

import cart.ShoppingCart;
import cart.ShoppingCartItem;
import entity.Category;
import entity.Product;
import entity.User;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.CategoryModel;
import model.ProductModel;
import model.UserModel;
import web.ViewManager;

/**
 *
 * @author raquel
 */
public class neworderAction implements Action {
    
    CategoryModel categoryModel;
    ProductModel productModel;
    UserModel userModel;

    public neworderAction(CategoryModel categoryModel, ProductModel productModel, UserModel userModel){
        this.categoryModel = categoryModel;
        this.productModel = productModel;
        this.userModel = userModel;
    }

    public void perform(HttpServletRequest req, HttpServletResponse resp) {
        
        User user = null;
        int nItems = 0;
        //Recuperar dades de la request
        int categoryId = new Integer(req.getParameter("categoryid"));
        Category category = categoryModel.retrieve(categoryId);
        int productId = new Integer(req.getParameter("productid"));
        Product product = productModel.retrieve(productId);
        
        ShoppingCart shoppingCart = (ShoppingCart)req.getSession().getAttribute("shoppingCart");
        if (shoppingCart == null){
            shoppingCart = new ShoppingCart();
            req.getSession().setAttribute("shoppingCart", shoppingCart);
        }
        
        //acci�    
        shoppingCart.addItem(product);
        nItems = shoppingCart.getNumberOfItems();
        
        int idUser = new Integer(req.getParameter("idUser"));
        if(idUser != -1) {
            user = userModel.retrieve(idUser);
        }
        
        //Posar les dades que fara servir el jsp
        req.setAttribute("products", productModel.productsOfCategory(category));
        req.setAttribute("categories", categoryModel.retrieveAll());
        req.setAttribute("category", category);
        req.setAttribute("nItems", nItems);
        req.setAttribute("user", user);
        
        ViewManager.nextView(req, resp, "/view/category.jsp");
    }
}
