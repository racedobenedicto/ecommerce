/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package web.action;

import cart.ShoppingCart;
import entity.Comanda;
import entity.User;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.CategoryModel;
import model.ComandaModel;
import model.ProductModel;
import model.UserModel;
import web.ViewManager;

/**
 *
 * @author raque
 */
public class signinAction implements Action {
    
    CategoryModel categoryModel;
    UserModel userModel;
    ComandaModel comandaModel;
    ProductModel productModel;

    public signinAction(CategoryModel categoryModel, UserModel userModel, ComandaModel comandaModel, ProductModel productModel){
        this.categoryModel = categoryModel;
        this.userModel = userModel;
        this.comandaModel = comandaModel;
        this.productModel = productModel;
    }
    
    public void perform(HttpServletRequest req, HttpServletResponse resp) {
        
        String username = req.getParameter("user");
        
        ShoppingCart shoppingCart = (ShoppingCart)req.getSession().getAttribute("shoppingCart");
        if (shoppingCart == null){
            shoppingCart = new ShoppingCart();
            req.getSession().setAttribute("shoppingCart", shoppingCart);
        }
        req.setAttribute("nItems", shoppingCart.getNumberOfItems());
        
        int idUser = userModel.exist(username);
        if(idUser != -1) {
            String pass = req.getParameter("pass");
            User user = new User();

            req.setAttribute("categories", categoryModel.retrieveAll());
            req.setAttribute("user", userModel.retrieve(idUser));

            user.setUsername(username);
            user.setPassword(pass);
            userModel.insertUser(user);
            
            List<Comanda> lastOrders = comandaModel.retrieveAll(idUser);
            req.setAttribute("lastOrders", lastOrders);
            req.setAttribute("productModel", productModel);

            ViewManager.nextView(req, resp, "/view/init.jsp");
        } else {
            String error = "Duplicate user. Try again!";
            req.setAttribute("error", error);
            
            ViewManager.nextView(req, resp, "/view/login.jsp");
        }
    }
}
